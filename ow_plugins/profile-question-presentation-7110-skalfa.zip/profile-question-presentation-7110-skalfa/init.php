<?php

SKPROFILEQP_CLASS_EventHandler::getInstance()->init();